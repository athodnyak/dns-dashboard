  <?php
 require_once('db.php'); 
require_once('menu.php');
 echo '<link rel="stylesheet" type="text/css" href="http://192.117.235.123/style.css">';
$rec_limit = 50;
         $conn = mysql_connect($dbhost, $dbuser, $dbpass);
         
         if(! $conn ) {
            die('Could not connect: ' . mysql_error());
         }
         mysql_select_db('statdns');
          if( isset($_GET{'ip'} ) ) {
	$ip=$_GET{'ip'};
         /* Get total number of records */
         $sql =   "SELECT count(id) FROM logs where client = '$ip' and (length(query )-length(replace(query ,'.',''))) < 1  ";
         $retval = mysql_query( $sql, $conn );
         
         if(! $retval ) {
            die('Could not get data: ' . mysql_error());
         }
         $row = mysql_fetch_array($retval, MYSQL_NUM );
         $rec_count = $row[0];
         
         if( isset($_GET{'page'} ) ) {
            $page = $_GET{'page'} + 1;
            $offset = $rec_limit * $page ;
         }else {
            $page = 0;
            $offset = 0;
         }
         
         $left_rec = $rec_count - ($page * $rec_limit);
         $sql =   "select date, client, query, q_type, server ". 
              "FROM logs where client = '$ip' and (length(query )-length(replace(query ,'.',''))) < 1 order by date DESC ".
              "LIMIT $offset, $rec_limit  ";
            
         $retval = mysql_query( $sql, $conn );
         
         if(! $retval ) {
            die('Could not get data: ' . mysql_error());
         }
         echo   "<form method='GET'><table><th>date</th><th>client</th><th>query</th><th>q_type</th><th>server</th>  ";

         while($row = mysql_fetch_array($retval, MYSQL_ASSOC)) {
echo   "<tr><td> &nbsp ".$row["date"]."&nbsp </td><td><a href='/querys_per_ip.php/?ip=".$row["client"]."'> ".$row["client"]." </a>&nbsp</td><td>&nbsp<a href='/ip_per_query.php/?query=".trim($row["query"])."'>  ".$row["query"]." </a>&nbsp</td><td>&nbsp  ".$row["q_type"]."&nbsp </td><td> &nbsp ".$row["server"]."&nbsp </td></tr>  ";

}

if( $page > 0 ) {
 echo '</br>';
            $last = $page - 2;
            echo   "<a style='position:fixed;left:200px;' href=\"".$_SERVER['SCRIPT_NAME']."\?ip=$ip&page=$last\">Previous 50 Records</a>  ";
            echo   "<a style='position:fixed;' href=\"".$_SERVER['SCRIPT_NAME']."\?ip=$ip&page=$page\">Next 50 Records</a>  ";
         }else if( $page == 0 ) {
            echo   "<a style='position:fixed;' href=\"".$_SERVER['SCRIPT_NAME']."\?ip=$ip&page=$page\">Next 50 Records</a>  ";
         }else if( $left_rec < $rec_limit ) {
            $last = $page - 2;
            echo   "<a style='position:fixed;left:200px;' href=\"".$_SERVER['SCRIPT_NAME']."\?ip=$ip&page=$last\">Previous 50 Records</a>";
         }

         mysql_close($conn);
}
?>
